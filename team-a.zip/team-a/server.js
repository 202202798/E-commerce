const express = require("express");
const axios = require("axios");

const app = express();
const PORT = 3000;

app.use(express.json());

function createShipmentDelayedEvent(shipmentData) {
    return {
        event_id: `EVT-${Date.now()}`,
        event_type: "Shipment Delayed",
        timestamp: new Date().toISOString(),
        shipmentId: shipmentData.shipmentId,
        project_id: shipmentData.project_id,
        delayReason: shipmentData.delayReason,
        delayDays: shipmentData.delayDays
    };
}

app.get("/", (req, res) => {
    res.json({
        message: "SCM Node A Webhook Server is running",
        node: "Node A",
        system: "Supply Chain Management"
    });
});

app.post("/simulate-delay", async (req, res) => {

    const {
        shipmentId,
        project_id,
        delayReason,
        delayDays
    } = req.body;

    if (!shipmentId || !project_id || !delayReason || !delayDays) {
        return res.status(400).json({
            message: "Missing required fields",
            requiredFields: [
                "shipmentId",
                "project_id",
                "delayReason",
                "delayDays"
            ]
        });
    }

    const previousStatus = "In Transit";
    const newStatus = "Delayed";

    console.log(
        `Shipment ${shipmentId} status changed: ${previousStatus} -> ${newStatus}`
    );

    const event = createShipmentDelayedEvent({
        shipmentId,
        project_id,
        delayReason,
        delayDays
    });

    console.log("Shipment Delayed event created:");
    console.log(JSON.stringify(event, null, 2));

    try {
        const response = await axios.post(
            "http://localhost:4000/api/shipment-events",
            event,
            {
                headers: {
                    "Content-Type": "application/json"
                }
            }
        );

        console.log("Webhook sent successfully to Team B.");

        res.status(200).json({
            message: "Shipment Delayed webhook sent to Team B",
            event: event,
            teamBResponse: response.data
        });

    } catch (error) {

        console.error(
            "Webhook delivery to Team B failed:",
            error.message
        );

        res.status(502).json({
            message: "Webhook delivery to Team B failed",
            error: error.message,
            event: event
        });
    }
});

app.listen(PORT, () => {
    console.log(`SCM Node A running at http://localhost:${PORT}`);
});