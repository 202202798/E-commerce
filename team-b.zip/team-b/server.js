const express = require("express");

const app = express();
const PORT = 4000;
const API_KEY = process.env.API_KEY || "TEAM-B-2026";

app.use(express.json());

// Simple in-memory Project Management task store for Activity 5.
const tasks = new Map();

function validateShipmentEvent(body) {
    const requiredFields = [
        "event_id",
        "event_type",
        "shipmentId",
        "project_id",
        "delayReason"
    ];

    const missingFields = requiredFields.filter(
        (field) => body[field] === undefined || body[field] === null || body[field] === ""
    );

    const errors = [];

    if (missingFields.length > 0) {
        errors.push(`Missing required fields: ${missingFields.join(", ")}`);
    }

    if (body.event_id !== undefined && typeof body.event_id !== "string") {
        errors.push("event_id must be a string");
    }

    if (body.event_type !== undefined && body.event_type !== "Shipment Delayed") {
        errors.push('event_type must be "Shipment Delayed"');
    }

    if (body.shipmentId !== undefined && typeof body.shipmentId !== "string") {
        errors.push("shipmentId must be a string");
    }

    if (body.project_id !== undefined && typeof body.project_id !== "string") {
        errors.push("project_id must be a string");
    }

    if (body.delayReason !== undefined && typeof body.delayReason !== "string") {
        errors.push("delayReason must be a string");
    }

    if (body.delayDays !== undefined && (!Number.isInteger(body.delayDays) || body.delayDays < 1)) {
        errors.push("delayDays must be a positive integer");
    }

    return errors;
}

function validateProjectFields(body) {
    const errors = [];
    const projectId = body.projectId || body.project_id;

    if (!projectId || typeof projectId !== "string") {
        errors.push("projectId/project_id is required and must be a string");
    }

    if (body.taskId !== undefined && typeof body.taskId !== "string") {
        errors.push("taskId must be a string");
    }

    if (body.impactNotes !== undefined && typeof body.impactNotes !== "string") {
        errors.push("impactNotes must be a string");
    }

    return errors;
}

function authenticate(req, res, next) {
    const suppliedKey = req.get("X-API-Key");

    // Authentication is enabled when X-API-Key is supplied.
    // Team A can connect without the header for the classroom demo.
    if (suppliedKey && suppliedKey !== API_KEY) {
        return res.status(401).json({
            success: false,
            message: "Invalid API key"
        });
    }

    next();
}

app.get("/", (req, res) => {
    res.json({
        message: "PM Node B REST API Server is running",
        node: "Node B",
        system: "Project Management",
        endpoint: "POST /api/shipment-events",
        port: PORT
    });
});

app.get("/api/health", (req, res) => {
    res.json({
        success: true,
        status: "UP",
        node: "Node B",
        system: "Project Management"
    });
});

app.get("/api/tasks", (req, res) => {
    res.json({
        success: true,
        count: tasks.size,
        tasks: Array.from(tasks.values())
    });
});

app.post("/api/shipment-events", authenticate, (req, res) => {
    const body = req.body;

    if (!body || typeof body !== "object" || Array.isArray(body)) {
        return res.status(400).json({
            success: false,
            message: "Request body must be a JSON object"
        });
    }

    const eventErrors = validateShipmentEvent(body);
    const projectErrors = validateProjectFields(body);
    const errors = [...new Set([...eventErrors, ...projectErrors])];

    if (errors.length > 0) {
        return res.status(400).json({
            success: false,
            message: "Incoming REST API validation failed",
            errors
        });
    }

    // event_id is the idempotency key.
    if (tasks.has(body.event_id)) {
        return res.status(200).json({
            success: true,
            duplicate: true,
            message: "Duplicate event ignored because event_id was already processed",
            idempotencyKey: body.event_id,
            task: tasks.get(body.event_id)
        });
    }

    const projectId = body.projectId || body.project_id;
    const taskId = body.taskId || `TASK-${body.shipmentId}`;
    const impactNotes = body.impactNotes || `Shipment ${body.shipmentId} delayed: ${body.delayReason}`;

    // Team C may send the transformed status. If it is not present,
    // Team B records the incoming Shipment Delayed event as On_Hold.
    const taskStatus = body.taskStatus || (body.newStatus === "Delayed" ? "On_Hold" : "On_Hold");

    const task = {
        taskId,
        projectId,
        shipmentId: body.shipmentId,
        taskStatus,
        impactNotes,
        delayReason: body.delayReason,
        delayDays: body.delayDays || null,
        sourceEventId: body.event_id,
        receivedAt: new Date().toISOString()
    };

    tasks.set(body.event_id, task);

    console.log("Incoming Shipment Delayed event received:");
    console.log(JSON.stringify(body, null, 2));
    console.log(`PM task ${taskId} updated: ${taskStatus}`);

    return res.status(201).json({
        success: true,
        message: "Shipment Delayed event received and processed by Team B",
        eventId: body.event_id,
        projectId,
        taskId,
        taskStatus,
        task
    });
});

// JSON parsing error handler.
app.use((err, req, res, next) => {
    if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
        return res.status(400).json({
            success: false,
            message: "Invalid JSON format"
        });
    }

    next(err);
});

app.listen(PORT, () => {
    console.log(`PM Node B running at http://localhost:${PORT}`);
    console.log(`Incoming endpoint: POST http://localhost:${PORT}/api/shipment-events`);
    console.log(`Demo API key: ${API_KEY}`);
});
