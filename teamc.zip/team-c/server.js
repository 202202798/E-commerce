const express = require("express");

const app = express();
const PORT = 5000;

app.use(express.json());

// Receive event from Team B
app.post("/api/shipment-events", (req, res) => {

    const event = req.body;

    console.log("=================================");
    console.log("TEAM C - Event Received from Team B");
    console.log("=================================");
    console.log(event);

    // Validate required fields
    if (
        !event.event_id ||
        !event.shipmentId ||
        !event.project_id ||
        !event.delayReason ||
        !event.newStatus
    ) {
        return res.status(400).json({
            success: false,
            message: "Missing required fields"
        });
    }

    // Transform Team B data
    const transformedEvent = {
        idempotencyKey: event.event_id,
        shipmentId: event.shipmentId,
        projectId: event.project_id,
        taskStatus: event.newStatus === "Delayed"
            ? "On_Hold"
            : event.newStatus,
        impactNotes: event.delayReason,
        eventType: event.eventType
    };

    console.log("=================================");
    console.log("TEAM C - Transformed Data");
    console.log("=================================");
    console.log(transformedEvent);

    // Send transformed result back
    res.status(200).json({
        success: true,
        message: "Event received and transformed successfully",
        transformedEvent: transformedEvent
    });
});

// Test Team C
app.get("/", (req, res) => {
    res.json({
        message: "Middleware Node C is running",
        node: "Node C",
        system: "Middleware"
    });
});

// Start Team C
app.listen(PORT, () => {
    console.log(`Middleware Node C running at http://localhost:${PORT}`);
});